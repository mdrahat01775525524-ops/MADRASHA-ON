package com.madrasahone.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Green = Color(0xFF075B46)
private val Gold = Color(0xFFD7A94B)
private val Cream = Color(0xFFF5F7F2)

data class LocalNotice(val id: Long, val title: String, val body: String, val savedAt: Long)

private class OfflineStore(context: Context) {
    private val prefs = context.getSharedPreferences("madrasah_one_local", Context.MODE_PRIVATE)

    fun loadNotices(): List<LocalNotice> {
        val raw = prefs.getString("notices", "[]") ?: "[]"
        val array = JSONArray(raw)
        return (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            LocalNotice(o.getLong("id"), o.getString("title"), o.getString("body"), o.getLong("savedAt"))
        }.reversed()
    }

    fun saveNotice(title: String, body: String): List<LocalNotice> {
        val all = loadNotices().toMutableList()
        all.add(0, LocalNotice(System.currentTimeMillis(), title, body, System.currentTimeMillis()))
        val array = JSONArray()
        all.reversed().forEach {
            array.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("savedAt", it.savedAt))
        }
        prefs.edit().putString("notices", array.toString()).apply()
        return all
    }

    fun deleteNotice(id: Long): List<LocalNotice> {
        val remaining = loadNotices().filterNot { it.id == id }
        val array = JSONArray()
        remaining.reversed().forEach {
            array.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("savedAt", it.savedAt))
        }
        prefs.edit().putString("notices", array.toString()).apply()
        return remaining
    }
}

data class Module(val bn: String, val en: String, val ar: String, val icon: ImageVector, val desc: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MadrasahOneTestApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MadrasahOneTestApp() {
    val context = LocalContext.current
    val store = remember { OfflineStore(context) }
    var language by remember { mutableStateOf("বাংলা") }
    var page by remember { mutableStateOf("home") }
    var notices by remember { mutableStateOf(store.loadNotices()) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var questionDraft by remember { mutableStateOf("") }
    var questionSaved by remember { mutableStateOf(false) }
    val modules = listOf(
        Module("প্রশ্নপত্র মেকার", "Question Paper Maker", "منشئ الأسئلة", Icons.Default.Description, "প্রশ্নপত্রের খসড়া লিখে এই ফোনে সংরক্ষণ করুন।"),
        Module("রেজাল্ট ও মার্কশিট", "Results & Marksheets", "النتائج وكشوف الدرجات", Icons.Default.Assessment, "পরবর্তী পরীক্ষামূলক সংস্করণে যুক্ত হবে।"),
        Module("শিক্ষার্থী ভর্তি", "Student Admission", "قبول الطلاب", Icons.Default.PersonAdd, "পরবর্তী পরীক্ষামূলক সংস্করণে যুক্ত হবে।"),
        Module("নোটিশ বোর্ড", "Notice Board", "لوحة الإعلانات", Icons.Default.Campaign, "নোটিশ অফলাইনে ফোনে সংরক্ষণ করুন।"),
        Module("শিক্ষক ব্যবস্থাপনা", "Teacher Management", "إدارة المعلمين", Icons.Default.Groups, "পরবর্তী পরীক্ষামূলক সংস্করণে যুক্ত হবে।"),
        Module("মাদ্রাসার হিসাব", "Accounts", "الحسابات", Icons.Default.AccountBalanceWallet, "পরবর্তী পরীক্ষামূলক সংস্করণে যুক্ত হবে।"),
        Module("ইসলামিক লাইব্রেরি", "Islamic Library", "المكتبة الإسلامية", Icons.Default.MenuBook, "পরবর্তী পরীক্ষামূলক সংস্করণে যুক্ত হবে।"),
        Module("সেটিংস", "Settings", "الإعدادات", Icons.Default.Settings, "ভাষা পরিবর্তন করুন।")
    )

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Gold, background = Cream)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("MADRASAH ONE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                            Text("OFFLINE TEST • v1.1", color = Color.White.copy(alpha = .8f), fontSize = 10.sp)
                        }
                    },
                    actions = {
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            TextButton(onClick = { expanded = true }) { Text(language, color = Color.White) }
                            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                listOf("বাংলা", "English", "العربية").forEach { lang ->
                                    DropdownMenuItem(text = { Text(lang) }, onClick = { language = lang; expanded = false })
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Green)
                )
            }
        ) { padding ->
            when (page) {
                "home" -> Column(Modifier.fillMaxSize().background(Cream).padding(padding).padding(16.dp)) {
                    Card(colors = CardDefaults.cardColors(containerColor = Green), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            Text(if(language=="বাংলা") "আসসালামু আলাইকুম" else if(language=="English") "Assalamu Alaikum" else "السلام عليكم",
                                color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Text(if(language=="বাংলা") "ইন্টারনেট ছাড়াও কিছু কাজ করা যাবে" else if(language=="English") "Some features work without internet" else "تعمل بعض الميزات بدون إنترنت",
                                color = Color.White.copy(alpha=.9f), modifier = Modifier.padding(top=6.dp))
                            Text("● Offline ready • Local save", color = Gold, modifier = Modifier.padding(top=12.dp), fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Text(if(language=="বাংলা") "সেবা সমূহ" else if(language=="English") "Services" else "الخدمات",
                        color = Green, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical=14.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(modules) { m ->
                            Card(onClick = {
                                page = when(m.bn) {
                                    "নোটিশ বোর্ড" -> "notices"
                                    "প্রশ্নপত্র মেকার" -> "questions"
                                    "সেটিংস" -> "settings"
                                    else -> "coming"
                                }
                            }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(m.icon, contentDescription = null, tint = Green, modifier = Modifier.size(28.dp))
                                    Text(if(language=="বাংলা") m.bn else if(language=="English") m.en else m.ar,
                                        modifier = Modifier.weight(1f).padding(horizontal=14.dp), fontWeight = FontWeight.SemiBold)
                                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Green)
                                }
                            }
                        }
                    }
                }
                "notices" -> Column(Modifier.fillMaxSize().background(Cream).padding(padding).padding(16.dp)) {
                    BackButton { page = "home" }
                    Text("নোটিশ বোর্ড", fontSize = 22.sp, color = Green, fontWeight = FontWeight.Bold)
                    Text("নোটিশ ফোনে সংরক্ষিত হবে—ইন্টারনেট লাগবে না।", fontSize = 13.sp)
                    OutlinedTextField(title, { title = it }, label = { Text("নোটিশের শিরোনাম") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(body, { body = it }, label = { Text("নোটিশের বিস্তারিত") }, modifier = Modifier.fillMaxWidth().heightIn(min=100.dp))
                    Button(onClick = {
                        if(title.isNotBlank() && body.isNotBlank()) {
                            notices = store.saveNotice(title.trim(), body.trim())
                            title = ""; body = ""
                        }
                    }, colors = ButtonDefaults.buttonColors(containerColor = Green), modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Save, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("অফলাইনে সংরক্ষণ")
                    }
                    Text("সংরক্ষিত নোটিশ (${notices.size})", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top=14.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(notices) { n ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(n.title, fontWeight = FontWeight.Bold, color = Green)
                                    Text(n.body, modifier = Modifier.padding(vertical=5.dp))
                                    TextButton(onClick = { notices = store.deleteNotice(n.id) }) { Text("মুছে ফেলুন", color = Color.Red) }
                                }
                            }
                        }
                    }
                }
                "questions" -> Column(Modifier.fillMaxSize().background(Cream).padding(padding).padding(16.dp)) {
                    BackButton { page = "home" }
                    Text("প্রশ্নপত্র মেকার — পরীক্ষামূলক", fontSize = 21.sp, color = Green, fontWeight = FontWeight.Bold)
                    Text("প্রশ্নপত্রের খসড়া লিখুন। আপাতত এই স্ক্রিনে খসড়া রাখা যাবে; পরের ধাপে PDF তৈরি যুক্ত হবে।", fontSize = 13.sp)
                    OutlinedTextField(questionDraft, { questionDraft = it; questionSaved = false },
                        label = { Text("প্রশ্নপত্রের খসড়া") }, modifier = Modifier.fillMaxWidth().heightIn(min=180.dp))
                    Button(onClick = {
                        context.getSharedPreferences("madrasah_one_local", Context.MODE_PRIVATE)
                            .edit().putString("question_draft", questionDraft).apply()
                        questionSaved = true
                    }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("এই ফোনে খসড়া সংরক্ষণ") }
                    LaunchedEffect(Unit) {
                        questionDraft = context.getSharedPreferences("madrasah_one_local", Context.MODE_PRIVATE)
                            .getString("question_draft", "") ?: ""
                    }
                    if(questionSaved) Text("খসড়া এই ফোনে সংরক্ষিত হয়েছে।", color = Green)
                }
                "settings" -> Column(Modifier.fillMaxSize().background(Cream).padding(padding).padding(16.dp)) {
                    BackButton { page = "home" }
                    Text("ভাষা / Language / اللغة", fontSize = 22.sp, color = Green, fontWeight = FontWeight.Bold)
                    listOf("বাংলা", "English", "العربية").forEach { lang ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = language == lang, onClick = { language = lang })
                            Text(lang)
                        }
                    }
                }
                else -> Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                    BackButton { page = "home" }
                    Text("এই সুবিধাটি পরবর্তী সংস্করণে তৈরি হবে।", fontSize = 18.sp)
                }
            }
        }
    }
}

@Composable
private fun BackButton(onClick: () -> Unit) {
    TextButton(onClick = onClick) { Text("← ফিরে যান", color = Green) }
}
